dark_color, light_color = [
    ("#1A2A6C", "#AED9E0"),  # Fix to `blue` as it is a e2e app, and not a demo
    ("#800020", "#F6DFD7"),
    ("#4B0082", "#E6E6FA"),
    ("#006D5B", "#A2D5C6"),
][0]

adjectives = [
    "charming",
    "cuddly",
    "elegant",
    "fierce",
    "graceful",
    "majestic",
    "playful",
    "quirky",
    "silly",
    "witty",
]

animals = [
    "elephant",
    "giraffe",
    "jaguar",
    "koala",
    "lemur",
    "otter",
    "panda",
    "panther",
    "penguin",
    "zebra",
]

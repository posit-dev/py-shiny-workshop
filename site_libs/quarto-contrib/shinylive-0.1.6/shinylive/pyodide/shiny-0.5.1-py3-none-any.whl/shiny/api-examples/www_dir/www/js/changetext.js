document.getElementById("target").innerText = "If you see this text, it worked!";
document.getElementById("target").style.backgroundColor = "limegreen";

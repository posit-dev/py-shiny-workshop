from ._dataframe import output_data_frame

__all__ = ("output_data_frame",)
